document.getElementById('load-workouts').addEventListener('click', function() {
    fetch('/api/workouts')
        .then(response => response.json())
        .then(data => {
            const workoutList = document.getElementById('workout-list');
            workoutList.innerHTML = data.map(workout => `
                <div>
                    <h3>${workout.workoutType}</h3>
                    <p>Duration: ${workout.duration} minutes</p>
                    <p>Calories Burned: ${workout.caloriesBurned}</p>
                    <p>Date: ${new Date(workout.date).toLocaleDateString()}</p>
                </div>
            `).join('');
        })
        .catch(error => console.error('Error loading workouts:', error));
});
