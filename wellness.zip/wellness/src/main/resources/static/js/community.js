document.getElementById('load-posts').addEventListener('click', function() {
    fetch('/api/community-posts')
        .then(response => response.json())
        .then(data => {
            const communityPostsList = document.getElementById('community-posts-list');
            communityPostsList.innerHTML = data.map(post => `
                <div>
                    <p>${post.content}</p>
                    <small>Posted on: ${new Date(post.createdAt).toLocaleDateString()}</small>
                </div>
            `).join('');
        })
        .catch(error => console.error('Error loading posts:', error));
});
