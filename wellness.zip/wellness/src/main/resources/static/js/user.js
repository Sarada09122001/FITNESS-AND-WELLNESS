document.getElementById('load-users').addEventListener('click', function() {
    fetch('/api/users')
        .then(response => response.json())
        .then(data => {
            const userList = document.getElementById('user-list');
            userList.innerHTML = data.map(user => `
                <div>
                    <h3>${user.fullName}</h3>
                    <p>Email: ${user.email}</p>
                </div>
            `).join('');
        })
        .catch(error => console.error('Error loading users:', error));
});
