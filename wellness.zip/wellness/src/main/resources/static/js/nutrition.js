document.getElementById('load-nutrition').addEventListener('click', function() {
    fetch('/api/nutrition')
        .then(response => response.json())
        .then(data => {
            const nutritionList = document.getElementById('nutrition-list');
            nutritionList.innerHTML = data.map(nutrition => `
                <div>
                    <h3>${nutrition.mealType}</h3>
                    <p>Calories: ${nutrition.calories}</p>
                    <p>Protein: ${nutrition.protein} grams</p>
                    <p>Carbs: ${nutrition.carbs} grams</p>
                    <p>Fats: ${nutrition.fats} grams</p>
                    <p>Date: ${new Date(nutrition.date).toLocaleDateString()}</p>
                </div>
            `).join('');
        })
        .catch(error => console.error('Error loading nutrition records:', error));
});
