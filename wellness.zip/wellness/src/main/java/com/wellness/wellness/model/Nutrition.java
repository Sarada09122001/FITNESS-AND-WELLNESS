package com.wellness.wellness.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "nutrition")
public class Nutrition {

	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @ManyToOne
	    @JoinColumn(name = "user_id", nullable = false)
	    private User user;

	    private String mealType;
	    private int calories;
	    private int protein;
	    private int carbs;
	    private int fats;

	    @Temporal(TemporalType.DATE)
	    private Date date;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public String getMealType() {
			return mealType;
		}

		public void setMealType(String mealType) {
			this.mealType = mealType;
		}

		public int getCalories() {
			return calories;
		}

		public void setCalories(int calories) {
			this.calories = calories;
		}

		public int getProtein() {
			return protein;
		}

		public void setProtein(int protein) {
			this.protein = protein;
		}

		public int getCarbs() {
			return carbs;
		}

		public void setCarbs(int carbs) {
			this.carbs = carbs;
		}

		public int getFats() {
			return fats;
		}

		public void setFats(int fats) {
			this.fats = fats;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

	    // Getters and Setters
	}

