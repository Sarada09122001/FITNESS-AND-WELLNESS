package com.wellness.wellness.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wellness.wellness.model.Nutrition;
import com.wellness.wellness.service.NutritionService;

@RestController
@RequestMapping("/api/nutrition")
public class NutritionController {
    @Autowired
    private NutritionService nutritionService;

    @GetMapping
    public List<Nutrition> getAllNutritionRecords() {
        return nutritionService.getAllNutritionRecords();
    }

    @GetMapping("/user/{userId}")
    public List<Nutrition> getNutritionByUserId(@PathVariable Long userId) {
        return nutritionService.getNutritionByUserId(userId);
    }

    @PostMapping
    public Nutrition createNutrition(@RequestBody Nutrition nutrition) {
        return nutritionService.createNutrition(nutrition);
    }

    @DeleteMapping("/{id}")
    public void deleteNutrition(@PathVariable Long id) {
        nutritionService.deleteNutrition(id);
    }

    // Additional endpoints as needed
 }

