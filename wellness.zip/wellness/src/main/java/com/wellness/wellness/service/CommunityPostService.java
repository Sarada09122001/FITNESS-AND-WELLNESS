package com.wellness.wellness.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wellness.wellness.Repository.CommunityPostRepository;
import com.wellness.wellness.model.CommunityPost;

@Service
public class CommunityPostService {
    @Autowired
    private CommunityPostRepository communityPostRepository;

    public List<CommunityPost> getAllPosts() {
        return communityPostRepository.findAll();
    }

    public List<CommunityPost> getPostsByUserId(Long userId) {
        return communityPostRepository.findByUserId(userId);
    }

    public CommunityPost createPost(CommunityPost post) {
        return communityPostRepository.save(post);
    }

    public void deletePost(Long id) {
        communityPostRepository.deleteById(id);
    }

    // Additional methods as needed
}
