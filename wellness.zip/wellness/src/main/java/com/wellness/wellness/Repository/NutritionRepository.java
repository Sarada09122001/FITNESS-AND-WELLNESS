package com.wellness.wellness.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wellness.wellness.model.Nutrition;

public interface NutritionRepository extends JpaRepository<Nutrition, Long> {
    List<Nutrition> findByUserId(Long userId);
}
