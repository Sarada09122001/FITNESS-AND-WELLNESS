package com.wellness.wellness.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wellness.wellness.model.CommunityPost;

public interface CommunityPostRepository extends JpaRepository<CommunityPost, Long> {
    List<CommunityPost> findByUserId(Long userId);
}
