package com.wellness.wellness.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wellness.wellness.Repository.NutritionRepository;
import com.wellness.wellness.model.Nutrition;

@Service
public class NutritionService {
    @Autowired
    private NutritionRepository nutritionRepository;

    public List<Nutrition> getAllNutritionRecords() {
        return nutritionRepository.findAll();
    }

    public List<Nutrition> getNutritionByUserId(Long userId) {
        return nutritionRepository.findByUserId(userId);
    }

    public Nutrition createNutrition(Nutrition nutrition) {
        return nutritionRepository.save(nutrition);
    }

    public void deleteNutrition(Long id) {
        nutritionRepository.deleteById(id);
    }

    // Additional methods as needed
}
